
	<footer>
		<div id="copyright">
		<?php wp_nav_menu(array(
				'theme_location'  => 'footernav',
				'container' 	  => '',
				'menu_id'         => 'bottomnav',
				'menu_class'      => 'bottomnavcopy',
			)); ?> 

			<br /><br /><br />
			Copyright © 2014 Aptitude Health. All rights reserved.
			
		</div>
	</footer>
	<?php wp_footer(); ?>	
</body>
</html>